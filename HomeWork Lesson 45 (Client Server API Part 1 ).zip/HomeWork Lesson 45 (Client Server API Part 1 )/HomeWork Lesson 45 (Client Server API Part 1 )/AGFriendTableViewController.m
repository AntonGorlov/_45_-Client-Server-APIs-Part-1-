//
//  AGFriendTableViewController.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 25.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGFriendTableViewController.h"
#import "AGServerManager.h"
#import "AGUsersModel.h"
#import <UIImageView+AFNetworking.h>
#import "AGDetailFriendTableViewController.h"


@interface AGFriendTableViewController ()


@property (strong, nonatomic) NSMutableArray *friendsArray;
@property (assign, nonatomic) BOOL loadingCell; //for load data

@end

@implementation AGFriendTableViewController

static NSInteger friendsCountInRequest = 20;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.friendsArray = [NSMutableArray array];
    self.loadingCell = YES;
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - API

- (void) loadData {
    [[AGServerManager sharedManager]
     getFrindsForUser:@"12198336"
     offset:[self.friendsArray count]
     count:friendsCountInRequest
     onSuccess:^(NSArray *friends) {
         
         [self.friendsArray addObjectsFromArray:friends];
         
         NSMutableArray *newPaths = [NSMutableArray array];
         for (int i = (int)[self.friendsArray count] - (int)[friends count]; i < [self.friendsArray count];i++) {
             [newPaths addObject:[NSIndexPath indexPathForRow:i inSection:0]];
         }
         [self.tableView beginUpdates];
         [self.tableView insertRowsAtIndexPaths:newPaths withRowAnimation:UITableViewRowAnimationTop];
         [self.tableView endUpdates];
         
        //or // [self.tableView reloadData];
         self.loadingCell = NO;
                                                 }
     onFailure:^(NSError *error, NSInteger statusCode) {
         
         NSLog(@"ERROR: %@",[error localizedDescription]);
     }];
}

#pragma mark - UITableViewDataSource


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.friendsArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"Сell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
    }
 
    [self configureCell:cell forIndexPath:indexPath];
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    AGUsersModel *userModel = [self.friendsArray objectAtIndex:indexPath.row];
    
    if (userModel.isOnline ) {
        
       cell.detailTextLabel.text = @"Online";
    }
    return cell;
}

- (void) configureCell:(UITableViewCell*) cell forIndexPath:(NSIndexPath*) indexPath {

    AGUsersModel *userModel = [self.friendsArray objectAtIndex:indexPath.row];

    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",userModel.firstName, userModel.lastName];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:userModel.avatarUser];
    
    UIImage *placeholderImage = [UIImage imageNamed:@"Xlarge Icons-96"];
    __weak UITableViewCell *weakCell = cell;
    
      
    [cell.imageView setImageWithURLRequest:request
                          placeholderImage:placeholderImage success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
                              
                              weakCell.imageView.image = image;
                              [weakCell layoutSubviews];
                                  weakCell.imageView.layer.cornerRadius = weakCell.imageView.frame.size.width / 3;
                                  weakCell.imageView.layer.masksToBounds = YES;
                              
                              [UIView transitionWithView:weakCell.imageView duration:0.5 options:UIViewAnimationOptionTransitionFlipFromLeft animations:^{
                                  weakCell.imageView.image = image;
                                  
                               
                              } completion:nil];
                              
                          } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
                              
                          }];
    
  
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    AGUsersModel *userModel = [self.friendsArray objectAtIndex:indexPath.row];
   
    [self pushDetailViewController:userModel.userID
                         firstName:userModel.firstName
                          lastName:userModel.lastName
                          cityUser:userModel.cityID
                         imageView:userModel.avatarBig
                          birthDay:userModel.birhtDate
                         education:userModel.educationUser]; 
}

#pragma mark - PushVC

- (void) pushDetailViewController:(NSString*) userID
                        firstName:(NSString*) firstName
                         lastName:(NSString*) lastName
                         cityUser:(NSString*) city
                        imageView:(NSURL*)    imageUser
                         birthDay:(NSDate*)   bDay
                        education:(NSString*) name {

    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    AGDetailFriendTableViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"AGDetailFriendTableViewController"];
    
//передаем данные
    vc.userID = userID;
    vc.firstName = firstName;
    vc.lastName = lastName;
    vc.cityID = city;
    vc.imageURLMax = imageUser;
    vc.bDate = bDay;
    vc.education = name;
    
    [self.navigationController pushViewController:vc animated:YES];
}
//for load other a data
#pragma mark - UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height) {
        if (!self.loadingCell) {
            [self loadData];
            self.loadingCell = YES;
        }
    }
}

@end
