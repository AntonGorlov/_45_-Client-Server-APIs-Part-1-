//
//  AGDetailFriendTableViewController.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 27.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDetailFriendTableViewController.h"
#import "AGUsersModel.h"
#import "AGFriendTableViewController.h"
#import <UIImageView+AFNetworking.h>
#import "AGServerManager.h"
#import "AGSubscriptionsUserTableViewController.h"
#import "AGFollowersUserTableViewController.h"
#import "AGWallUserTableViewController.h"
#import "AGwallUsersModel.h"

@interface AGDetailFriendTableViewController () <UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) AGUsersModel *userModel;
@property (strong, nonatomic) AGwallUsersModel *wallModel;

@end


@implementation AGDetailFriendTableViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"Friend info";
    
    [self loadData];
    
    self.nameUsers.text = [NSString stringWithFormat:@"%@ %@", self.firstName, self.lastName];
    self.iDUsers.text   = [NSString stringWithFormat:@"ID: %@",self.userID];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark - API

- (void) loadData {
    
    //get users
    [[AGServerManager sharedManager]
     getUsersForDetailVC:self.userID
     onSuccess:^(AGUsersModel *user) {
         
         self.userModel = user;
         
         if (user.educationUser == nil) {
             
              self.educationUser.text = @"University:Unknown";
             
         }else {
             
         self.educationUser.text = [NSString stringWithFormat:@"University:%@",user.educationUser];
             
         }
         
         if (user.birhtDate == nil) {
             
             self.bDay.text = @"Date:Unknown";
             
         }else {
         
          self.bDay.text = [NSString stringWithFormat:@"Date: %@", user.birhtDate];
             
         }
         
         if (user.isOnline) {
             
             self.statusUser.text = @"Online";
             
         }else {
             
             self.statusUser.text = @"Offline";
         }
         
         [[AGServerManager sharedManager] getCityNameID:user.cityID
                                               onSucces:^(NSString *cityName) {
                                                 
                                                   self.cityUsers.text = [NSString stringWithFormat:@"City: %@ ",cityName];
                                               }
                                              onFailure:^(NSError *error, NSInteger statusCode) {
                                                  
                                                 
                                                  NSLog(@"Error %@",[error localizedDescription]);
                                              }];
         
         NSURLRequest *photoMax = [NSURLRequest requestWithURL:user.avatarBig];
         UIImage *placeholderImage = [UIImage imageNamed:@"1408180657_default_icon"];
         
         [self.imageUsers setImageWithURLRequest:photoMax
                                placeholderImage:placeholderImage
                                         success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
                                             
                                             self.imageUsers.image = image;
                                             
                                         } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {

                                         }];
         
         
         [self.tableView reloadData];
         
         
     }
     onFailure:^(NSError *error, NSInteger statusCode) {
         
         NSLog(@"Error: %@",[error localizedDescription]);
     }];
 
}

#pragma mark - Actions

- (IBAction)subscriptionsAction:(UIButton *)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    AGSubscriptionsUserTableViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"AGSubscriptionsUserTableViewController"];
    
    vc.userID = self.userID;
    
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (IBAction)followersAction:(UIButton *)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    AGFollowersUserTableViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"AGFollowersUserTableViewController"];
    
    vc.userID = self.userID;
    
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (IBAction)wallUserAction:(UIButton *)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AGWallUserTableViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"AGWallUserTableViewController"];
    
    vc.userID    = self.userID;
    vc.firstName = self.firstName;
    vc.lastName  = self.lastName;
    vc.postTitle = self.wallModel.postTitle;
    
    [self.navigationController pushViewController:vc animated:YES];
    
}


@end
