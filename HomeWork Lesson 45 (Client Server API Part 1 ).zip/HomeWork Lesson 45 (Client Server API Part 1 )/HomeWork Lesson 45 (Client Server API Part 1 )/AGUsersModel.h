//
//  AGUsersModel.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 26.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIImageView;

@interface AGUsersModel : NSObject

@property (strong, nonatomic) NSString *userID;
@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSURL    *avatarUser;

//detail

@property (strong, nonatomic) NSURL    *avatarBig; 
@property (strong, nonatomic) NSString *cityID;
@property (strong, nonatomic) NSDate   *birhtDate;
@property (assign, nonatomic) BOOL     isOnline;
@property (strong, nonatomic) NSString *educationUser;

//groups (subscriptions)

@property (strong, nonatomic) NSString *groupName;
@property (strong, nonatomic) NSString *groupID;
@property (strong, nonatomic) NSURL    *avatarGroup;


- (id) initWithServerResponse:(NSDictionary*) responseObject;

@end


