//
//  AGWallUserTableViewController.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 10.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AGUsersModel;
@class AGwallUsersModel;

@interface AGWallUserTableViewController : UITableViewController

@property (strong, nonatomic) AGUsersModel *userModel;
@property (strong, nonatomic) AGwallUsersModel *wallModel;

@property (strong, nonatomic) NSString *userID;
@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *postTitle;


@end
