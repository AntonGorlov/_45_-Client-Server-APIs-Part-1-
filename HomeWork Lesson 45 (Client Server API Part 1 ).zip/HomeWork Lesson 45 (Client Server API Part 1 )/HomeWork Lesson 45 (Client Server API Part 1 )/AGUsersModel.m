//
//  AGUsersModel.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 26.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGUsersModel.h"
#import "AGServerManager.h"

@implementation AGUsersModel

- (id) initWithServerResponse:(NSDictionary*) responseObject {

    self = [super init]; 
    
    if (self) {
        
        self.userID = [responseObject objectForKey:@"id"]; //user_id or uid
        self.firstName = [responseObject objectForKey:@"first_name"];
        self.lastName  = [responseObject objectForKey:@"last_name"];
       
        NSString *urlString1 = [responseObject objectForKey:@"photo_100"];
        NSString *urlString2 = [responseObject objectForKey:@"photo_max_orig"];

        if (urlString1) {
            self.avatarUser = [NSURL URLWithString:urlString1];
            
        }
        
        if (urlString2) {
            
            self.avatarBig = [NSURL URLWithString:urlString2];
        
        }
        
    //detail
        self.cityID    = [responseObject objectForKey:@"city"];
        self.birhtDate = [responseObject objectForKey:@"bdate"];
        self.educationUser = [responseObject objectForKey:@"university_name"];
        self.isOnline  = [[responseObject objectForKey:@"online"] boolValue];
        
    //groups
        self.groupID = [responseObject objectForKey:@"id"];
        self.groupName = [responseObject objectForKey:@"name"];
        
        NSString *urlStringGroup = [responseObject objectForKey:@"photo_100"];
        
        if (urlStringGroup) {
            self.avatarGroup = [NSURL URLWithString:urlStringGroup];
        }
    }

    return self;
}
@end
