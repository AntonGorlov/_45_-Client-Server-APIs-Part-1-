//
//  AGFollowersUserTableViewController.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 05.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGFollowersUserTableViewController.h"
#import "AGServerManager.h"
#import "AGUsersModel.h"
#import <UIImageView+AFNetworking.h>


@interface AGFollowersUserTableViewController ()

@property (strong, nonatomic) NSMutableArray *userFollowers;
@end

static NSInteger usersFollowerCountInRequest = 700;

@implementation AGFollowersUserTableViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationItem.title = @"Followers:";
    [self loadFollowersData];
    self.userFollowers = [NSMutableArray array];
}

#pragma mark - API

- (void) loadFollowersData {

    [[AGServerManager sharedManager]   getFollowersForUser:self.userID
                                       offSet:[self.userFollowers count]
                                       count:usersFollowerCountInRequest
                                       onSuccess:^(NSArray *followersUser) {
                                       
                                           [self.userFollowers addObjectsFromArray:followersUser];
                                           [self.tableView reloadData];
                                           
                                           self.followerCountlabel.text = [NSString stringWithFormat:@"%lu users",[self.userFollowers count]];
                                       }
                                       onFailure:^(NSError *error, NSInteger statusCode) {
                                           
                                            NSLog(@"ERROR: %@",[error localizedDescription]);
                                           
                                       }];

}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.userFollowers count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    AGUsersModel *userModel = [self.userFollowers objectAtIndex:indexPath.row];
    static NSString *identifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    __weak UITableViewCell *weakCell = cell;
    NSURLRequest *request = [NSURLRequest requestWithURL:userModel.avatarUser];
    UIImage *placeholder = [UIImage imageNamed:@"Xlarge Icons-96"];
    
    [cell.imageView
     setImageWithURLRequest:request
     placeholderImage:placeholder
     success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
         
         weakCell.imageView.image = image;
         [weakCell layoutSubviews];
         weakCell.imageView.layer.cornerRadius = weakCell.imageView.frame.size.width / 3;
         weakCell.imageView.layer.masksToBounds = YES;
     }
     failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
         
     }];
    [self configureCell:cell atIndexPath:indexPath];
    
    return cell;
}

- (void) configureCell:(UITableViewCell*) cell atIndexPath:(NSIndexPath*) indexPath {

 
    AGUsersModel *userModel = [self.userFollowers objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", userModel.firstName, userModel.lastName];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
