//
//  AGWallTableViewCell.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 10.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGWallTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *avatarUserImage;
@property (weak, nonatomic) IBOutlet UILabel     *nameSurnameUserLabel;
@property (weak, nonatomic) IBOutlet UILabel     *postDateLabel;
@property (weak, nonatomic) IBOutlet UILabel     *postTextLabel;
@property (weak, nonatomic) IBOutlet UILabel     *postTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *postImage;

@property (weak, nonatomic) IBOutlet UIImageView *commentsImage;
@property (weak, nonatomic) IBOutlet UILabel     *commentsCountLabel;
@property (weak, nonatomic) IBOutlet UIImageView *repostImage;
@property (weak, nonatomic) IBOutlet UILabel     *repostCountLabel;
@property (weak, nonatomic) IBOutlet UIImageView *likeImage;
@property (weak, nonatomic) IBOutlet UILabel     *likeCountLabel;

@end
