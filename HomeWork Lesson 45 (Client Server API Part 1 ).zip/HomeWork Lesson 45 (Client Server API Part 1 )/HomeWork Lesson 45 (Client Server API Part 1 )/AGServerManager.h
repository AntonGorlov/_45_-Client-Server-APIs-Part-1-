//
//  AGServerManager.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 25.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIImageView;
@class UIImage;
@class AGUsersModel;



@interface AGServerManager : NSObject

+ (AGServerManager*) sharedManager;



- (void) getFrindsForUser:(NSString *)userID
                   offset:(NSInteger) offset
                   count:(NSInteger) count
                   onSuccess:(void(^)(NSArray * friends)) success
                   onFailure:(void(^)(NSError * error,NSInteger statusCode)) failure;


- (void) getUsersForDetailVC:(NSString*)userID
                   onSuccess:(void(^)(AGUsersModel* user)) success 
                   onFailure:(void(^)(NSError * error,NSInteger statusCode)) failure;

- (void) getCityNameID:(NSString*)cityID
              onSucces:(void(^)(NSString* cityName)) success
             onFailure:(void(^)(NSError *error,NSInteger statusCode)) failure;

- (void) getSubscriptionsForUser:(NSString *)userID
                          offSet:(NSInteger) offset
                           count:(NSInteger) count
                       onSuccess:(void(^)(NSArray* subscriptionsGroups)) success
                       onFailure:(void(^)(NSError *error,NSInteger statusCode)) failure;

- (void) getFollowersForUser:(NSString*) userID
                      offSet:(NSInteger) offset
                       count:(NSInteger) count
                   onSuccess:(void(^)(NSArray *followersUser))  success
                   onFailure:(void(^)(NSError *error, NSInteger statusCode)) failure;

- (void) getWallForUser:(NSString*) userID
                 offSet:(NSInteger) offSet
                  count:(NSInteger) count
              onSuccess:(void(^)(NSMutableArray *wallUser)) success
              onFailure:(void(^)(NSError *error,NSInteger statusCode)) failure;

@end
