//
//  AGWallUserTableViewController.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 10.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGWallUserTableViewController.h"
#import "AGServerManager.h"
#import "AGUsersModel.h"
#import <UIImageView+AFNetworking.h>
#import "AGwallUsersModel.h"
#import "AGWallTableViewCell.h"

@interface AGWallUserTableViewController ()

@property (strong, nonatomic) NSMutableArray *wallArray;

@end

@implementation AGWallUserTableViewController

static NSInteger wallCountInRequest = 4;
const static NSInteger contsPostImageWidth = 320;

- (void)viewDidLoad {
    [super viewDidLoad];
    
   self.wallArray = [NSMutableArray array];

    [self loadWallUser];
    
    self.navigationItem.title = @"Wall:";
    NSLog(@"Wall %@ %@",self.firstName,self.lastName);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) loadWallUser {

    [[AGServerManager sharedManager]
     getWallForUser:self.userID
     offSet:[self.wallArray count]
     count:wallCountInRequest
     onSuccess:^(NSMutableArray *wallUser) {
         
         
         self.wallArray = wallUser;
         NSInteger objects = 0;
         
         for (AGwallUsersModel* wallPost in self.wallArray) {
             
             NSData* dataPostImage = [[NSData alloc] initWithContentsOfURL:wallPost.postImageURL];
             
             wallPost.postImage = [UIImage imageWithData:dataPostImage];
             
             if (self.userModel.avatarUser != nil) {
                 
                 NSData* dataUserImage = [[NSData alloc] initWithContentsOfURL:self.userModel.avatarUser];
                 wallPost.userImage = [UIImage imageWithData:dataUserImage];
                 
                 objects++;
                 
             }
             
             
         }
         [self.tableView reloadData];
         
         
         [self.tableView reloadData];
     }
     onFailure:^(NSError *error, NSInteger statusCode) {
         
         NSLog(@"FAILED TO LOAD USER WALL");
     }];
}

#pragma mark - UITableViewDataSource


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.wallArray count];
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    NSString* title;
    
    if ([self.wallArray count] == 1) {
        
        title = @"The wall closed";
        
    }
    
    return title;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"cell";

    AGwallUsersModel *wallPost = [self.wallArray objectAtIndex:indexPath.row];
    
        AGWallTableViewCell *wallCell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!wallCell) {
        
        wallCell = [[AGWallTableViewCell alloc ]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
        
        wallCell.nameSurnameUserLabel.text = [NSString stringWithFormat:@"%@ %@",self.firstName, self.lastName];
        
        wallCell.postDateLabel.text = wallPost.date;
        wallCell.postTextLabel.text = wallPost.postText;
//        NSLog(@"postTextLabel:%@",wallCell.postTextLabel.text);
    
        wallCell.postTitleLabel.text = wallPost.postTitle;
        //wallCell.postTitleLabel.text = [self removeHTMLTags:wallPost.postTitle];
        NSLog(@"postTitleLabel:%@",wallCell.postTitleLabel.text);
    
    
    
        wallCell.commentsCountLabel.text = wallPost.commentsCount;
        wallCell.repostCountLabel.text = wallPost.repostsCount;
        wallCell.likeCountLabel.text = wallPost.likesCount;
        
//        wallCell.avatarUserImage.image = wallPost.userImage;
        wallCell.avatarUserImage.layer.cornerRadius = wallCell.avatarUserImage.frame.size.height / 3;
        wallCell.avatarUserImage.layer.masksToBounds = YES;
        wallCell.avatarUserImage.layer.borderWidth = 0;

        if (wallPost.postImage != nil) {
            
            CGFloat proportionalHeight = (float)(wallPost.postImage.size.height / wallPost.postImage.size.width) * contsPostImageWidth;
            
            wallCell.postImage.image = [self imageWithImage:wallPost.postImage convertToSize:CGSizeMake(contsPostImageWidth, proportionalHeight)];
            
        } else {
            
            wallCell.postImage.image = wallPost.postImage;
            
        }
    
    return wallCell;

}


#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 540.f;
    
    
}

#pragma mark - Methods for size and View

- (NSString*) removeHTMLTags:(NSString*) string {
    
    NSRange r;
    
    if (string != nil) {
        
        while ((r = [string rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound) {
            
            string = [string stringByReplacingCharactersInRange:r withString:@""];
        }
        
    }
    
    return string;
}

- (UIImage *)imageWithImage:(UIImage *)image convertToSize:(CGSize)size {
    
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *destImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return destImage;
}
@end
