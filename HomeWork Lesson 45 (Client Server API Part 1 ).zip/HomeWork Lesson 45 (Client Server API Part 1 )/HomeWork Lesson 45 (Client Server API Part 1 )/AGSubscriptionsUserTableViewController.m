//
//  AGSubscriptionsUserTableViewController.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 03.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGSubscriptionsUserTableViewController.h"
#import "AGServerManager.h"
#import "AGUsersModel.h"
#import "AGDetailFriendTableViewController.h"
#import <UIImageView+AFNetworking.h>

@interface AGSubscriptionsUserTableViewController ()

@property (strong, nonatomic) AGUsersModel *userModel;
@property (strong, nonatomic) AGDetailFriendTableViewController *detailUser;
@property (strong, nonatomic) NSMutableArray *groupArray; //all groups 

@property (assign, nonatomic) BOOL loadingCell; //for load data
@end

static NSInteger groupsCountInRequest = 200; //if you don't remember look at API VK

@implementation AGSubscriptionsUserTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"Subscriptions:";
    self.loadingCell = YES;
    self.groupArray = [NSMutableArray array];
    [self loadDataGroups];
    

}

#pragma mark - API

- (void) loadDataGroups {
    
[[AGServerManager sharedManager] getSubscriptionsForUser:self.userID
                                                  offSet:[self.groupArray count]
                                                   count:groupsCountInRequest
                                               onSuccess:^(NSArray *subscriptionsGroups) {
                                                   
                                                   [self.groupArray addObjectsFromArray:subscriptionsGroups];
                                                   [self.tableView reloadData];
                                                   self.loadingCell = NO;
                                                   self.subscriptionsCountLabel.text = [NSString stringWithFormat:@"%ld groups",[self.groupArray count]];
                                                 
                                               }
                                               onFailure:^(NSError *error, NSInteger statusCode) {
                                                   
                                                   NSLog(@"ERROR: %@",[error localizedDescription]);
                                               }];
    
   
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.groupArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    AGUsersModel *userModel = [self.groupArray objectAtIndex:indexPath.row];

    static NSString *identifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    
    NSURLRequest *request = [NSURLRequest requestWithURL:userModel.avatarGroup];
    UIImage *placeholder = [UIImage imageNamed:@"Xlarge Icons-96"];
    __weak UITableViewCell *weakCell = cell;
    
    [cell.imageView
     setImageWithURLRequest:request
     placeholderImage:placeholder
     success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
         
         weakCell.imageView.image = image;
         [weakCell layoutSubviews];
         weakCell.imageView.layer.cornerRadius = weakCell.imageView.frame.size.width / 3;
         weakCell.imageView.layer.masksToBounds = YES;
         
     } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
         
     }];
    
    [self configureCell:cell forIndexPath:indexPath];
    
    return cell;
}

- (void) configureCell:(UITableViewCell*) cell forIndexPath:(NSIndexPath*) indexPath {

    AGUsersModel *userModel = [self.groupArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",userModel.groupName];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"group ID:%@",userModel.groupID];
    
    cell.detailTextLabel.textColor = [UIColor colorWithRed:(160/255.0) green:(97/255.0) blue:(5/255.0)alpha:0.5];
    
}

//for load other data
#pragma mark - UIScrollViewDelegate


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height) {
        if (!self.loadingCell) {
            [self loadDataGroups];
            self.loadingCell = YES;
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
