//
//  AGDetailFriendTableViewController.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 27.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AGUsersModel;

@interface AGDetailFriendTableViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageUsers;
@property (weak, nonatomic) IBOutlet UILabel     *cityUsers;
@property (weak, nonatomic) IBOutlet UILabel     *nameUsers;
@property (weak, nonatomic) IBOutlet UILabel     *iDUsers;
@property (weak, nonatomic) IBOutlet UILabel     *bDay;

@property (weak, nonatomic) IBOutlet UILabel *statusUser;
@property (weak, nonatomic) IBOutlet UILabel *educationUser;

@property (strong, nonatomic) NSString *userID;
@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *cityID;
@property (strong, nonatomic) NSString *education;
@property (strong, nonatomic) NSDate   *bDate;
@property (strong,nonatomic)   NSURL   *imageURL100;
@property (strong,nonatomic)   NSURL   *imageURLMax; //max size a avatar

//subscriptions and followers (Other controllers)

- (IBAction)subscriptionsAction:(UIButton *)sender;
- (IBAction)followersAction:(UIButton *)sender;

//wall
- (IBAction)wallUserAction:(UIButton *)sender;


@end
