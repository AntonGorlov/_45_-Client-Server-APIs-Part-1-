//
//  AGwallUsersModel.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 07.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class UIImageView;

@interface AGwallUsersModel : NSObject

@property (strong, nonatomic) NSString *postText;
@property (strong, nonatomic) NSString *postTitle;
@property (strong, nonatomic) NSString *date;
@property (strong, nonatomic) NSString *commentsCount;
@property (strong, nonatomic) NSString *likesCount;
@property (strong, nonatomic) NSString *repostsCount;

@property (strong, nonatomic) NSString* attachmentType; //attachment files

// далее свойства, которые зависят от attachmentType, которое может быть video, photo, link, doc
@property (strong, nonatomic) NSString     *wallError; // Если стена не доступна!
@property (strong, nonatomic) UIImage      *postImage;
@property (strong, nonatomic) UIImage      *userImage;
@property (strong, nonatomic) NSURL        *postImageURL;
@property (strong, nonatomic) NSDictionary *attachmentData;

- (id) initWithServerResponseForWall:(NSDictionary*) responseObject;
@end
