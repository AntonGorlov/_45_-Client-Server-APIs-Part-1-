//
//  AGSubscriptionsUserTableViewController.h
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 03.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AGUsersModel;

@interface AGSubscriptionsUserTableViewController : UITableViewController



@property (strong, nonatomic) NSString *userID;
@property (strong, nonatomic) NSString *nameGroup;

@property (weak, nonatomic) IBOutlet UILabel *subscriptionsCountLabel;



@end
