//
//  AGwallUsersModel.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 07.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGwallUsersModel.h"
#import "AGServerManager.h"

@implementation AGwallUsersModel

- (instancetype) initWithServerResponseForWall:(NSDictionary*) responseObject; {

    self = [super init];
    if (self) {
        
        if ([responseObject count] != 1) {
            
            self.commentsCount = [[[responseObject objectForKey:@"comments"] objectForKey:@"count"] stringValue];
            
            self.likesCount = [[[responseObject objectForKey:@"likes"] objectForKey:@"count"] stringValue];
            self.repostsCount = [[[responseObject objectForKey:@"reposts"] objectForKey:@"count"] stringValue];
            
            NSDateFormatter *dateFormater = [[NSDateFormatter alloc]init];
            
            [dateFormater setDateFormat:@"dd MMM yyyy "];
            
            NSDate *dateTime = [NSDate dateWithTimeIntervalSince1970:[[responseObject objectForKey:@"date"] floatValue]];
            
            self.date = [dateFormater stringFromDate:dateTime];
            self.postText = (NSString*)[responseObject objectForKey:@"text"];
            self.attachmentType = (NSString*)[responseObject objectForKey:@"attachments"];
            NSLog(@"/n ATTACHMENTS %@",[responseObject objectForKey:@"attachments"]);
            
            self.attachmentData = [responseObject objectForKey:@"type"];
            NSString *urlString = [self.attachmentData  objectForKey:@"photo_2560"];
            
            if (urlString) {
                self.postImageURL = [NSURL URLWithString:urlString];
            }
            
//            
//            if (self.attachmentType != nil) {
//                
//                self.attachmentData = [responseObject objectForKey:@"photo"];
//                self.postTitle = [self.attachmentData objectForKey:@"title"];
//                self.postImageURL = [NSURL URLWithString:[self.attachmentData objectForKey:@"photo_604"]];
//                
//                if (self.postImageURL == nil) {
//                    
//                    self.postText = (NSString*)[self.attachmentData objectForKey:@"url"];
//                    
//                }
//                
//            } else if ([self.attachmentType isEqual:[responseObject objectForKey:@"photo"]]) {
//                
//                self.attachmentData = [[responseObject objectForKey:@"type"] objectForKey:@"link"];
//                self.postTitle = [self.attachmentData objectForKey:@"title"];
//                self.postImageURL = [NSURL URLWithString:[self.attachmentData objectForKey:@"photo_604"]];
//                
//                if (self.postImageURL == nil) {
//                    
//                    self.postText = (NSString*)[self.attachmentData objectForKey:@"url"];
//                    
//                }
//                
//                
//            } else if ([self.attachmentType isEqual:[responseObject objectForKey:@"audio"]]) {
//                
//                self.attachmentData = [[responseObject objectForKey:@"type"] objectForKey:@"photo"];
//                self.postTitle = [self.attachmentData objectForKey:@"text"];
//                self.postImageURL = [NSURL URLWithString:[self.attachmentData objectForKey:@"src_big"]];
//                
//            } else if ([self.attachmentType isEqual:[responseObject objectForKey:@"doc"]]){
//                
//                
//                self.postImageURL = nil;
//                self.attachmentData = [[responseObject objectForKey:@"type"] objectForKey:@"audio"];
//                
//                NSString* artist = [self.attachmentData objectForKey:@"artist"];
//                NSString* title = [self.attachmentData objectForKey:@"title"];
//                
//                self.postTitle = [NSString stringWithFormat:@"%@ - %@", artist, title];
//                
//            } else if ([self.attachmentType isEqual:[responseObject objectForKey:@"doc"]]) {
//                
//                
//                self.attachmentData = [[responseObject objectForKey:@"type"] objectForKey:@"doc"];
//                self.postTitle = [self.attachmentData objectForKey:@"title"];
//                self.postImageURL = [NSURL URLWithString:[self.attachmentData objectForKey:@"thumb_s"]];
//                
//            } else {
//                
//                //self.postImageURL = nil;
//                
//            }
//            
//        } else {
//            
//            self.wallError = [responseObject objectForKey:@"wallError"];
//            
        }
        
    }
    return self;
}

@end
