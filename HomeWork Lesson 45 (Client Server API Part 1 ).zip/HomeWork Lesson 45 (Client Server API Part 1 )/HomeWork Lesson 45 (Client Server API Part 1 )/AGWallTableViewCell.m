//
//  AGWallTableViewCell.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 10.10.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGWallTableViewCell.h"

@implementation AGWallTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
