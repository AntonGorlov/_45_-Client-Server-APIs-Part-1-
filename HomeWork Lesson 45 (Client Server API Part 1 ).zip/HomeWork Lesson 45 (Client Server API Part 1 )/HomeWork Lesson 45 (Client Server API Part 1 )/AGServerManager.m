//
//  AGServerManager.m
//  HomeWork Lesson 45 (Client Server API Part 1 )
//
//  Created by Anton Gorlov on 25.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGServerManager.h"
#import <AFNetworking.h>
#import "AGUsersModel.h"
#import <UIImageView+AFNetworking.h>
#import "AGSubscriptionsUserTableViewController.h"
#import "AGwallUsersModel.h"

@interface AGServerManager ()

@property (strong, nonatomic) AFHTTPSessionManager* requestSessionManager;

@end
@implementation AGServerManager

+ (AGServerManager*) sharedManager {

    static AGServerManager *manager = nil;
    
    @synchronized (self) {
        
        if (!manager) {
            
            manager = [[self alloc]init]; //or AGServerManager
        }
    }
    
    return manager;
}

- (id) init {

    self = [super init];
    
    if (self) {
        
        NSURL *url = [NSURL URLWithString:@"https://api.vk.com/method/"];
        self.requestSessionManager = [[AFHTTPSessionManager alloc]initWithBaseURL:url];
        
    }
    
    return self;
}

- (void)showActivityIndicator {
    
    UIApplication* application = [UIApplication sharedApplication];
    
    if (!application.isNetworkActivityIndicatorVisible) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    }
    
}

- (void)hideActivityIndicator {
    
    UIApplication* application = [UIApplication sharedApplication];
    
    if (application.isNetworkActivityIndicatorVisible) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }
}

#pragma mark - Request APIs

- (void) getFrindsForUser:(NSString *)userID
                   offset:(NSInteger)offset
                    count:(NSInteger)count
                onSuccess:(void (^)(NSArray *))success
                onFailure:(void (^)(NSError *, NSInteger))failure {
    
    // params we get from http://vk.com/dev/friends.get
    
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                userID,                   @"user_id",
                                @"name",                  @"order",
                                @(count),                 @"count",
                                @(offset),                @"offset",
                                @"photo_100,online",      @"fields",
                                @"nom",                   @"name_case",
                                nil];
    
    [self showActivityIndicator];
    
    [self.requestSessionManager
     GET:@"friends.get?v=5.58" //?v=5.58
     parameters:parameters
     progress:nil
     success:^(NSURLSessionTask * _Nonnull task, id  _Nullable responseObject) {
     
//   NSLog(@"JSON : %@",responseObject);
     NSArray *dictArray = [[responseObject objectForKey:@"response"] objectForKey:@"items"];//СМОТРИ В КОНСОЛЬ ЧТО ПРИХОДИТ(СМОТРЯ КАКАЯ ВЕРСИЯ ?v=5.58)
         
         NSMutableArray *objectArray = [NSMutableArray array];
         
         for (NSDictionary *dictionary in dictArray) {
             
             AGUsersModel *userModel = [[AGUsersModel alloc]initWithServerResponse:dictionary];
             [objectArray addObject:userModel];
             
         }
         if (success) {
             
             success(objectArray);
         }
         [self hideActivityIndicator];
     }
     failure:^(NSURLSessionTask * _Nullable task, NSError * _Nonnull error) {
         
         NSLog(@"ERROR : %@",error );
         
         if (failure) {
             
             
             NSHTTPURLResponse* response = (NSHTTPURLResponse *)task.response;
             NSInteger statusCode = response.statusCode;
             
             NSLog(@"error: %@", [error localizedDescription]);
             
             failure(error, statusCode);
         }
     }];
}

- (void) getUsersForDetailVC:(NSString *)userID
                   onSuccess:(void(^)(AGUsersModel* user)) success //AGDetailUsersModel
                   onFailure:(void (^)(NSError *, NSInteger))failure {
    
    // params we get from https://vk.com/dev/users.get
    
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                
                    userID,                                                      @"user_ids",
                    @"photo_max_orig,city,bdate,online,education,universities",  @"fields",
                    @"Nom",                                                      @"name_case", nil];
    
    [self showActivityIndicator];
    
    [self.requestSessionManager GET:@"users.get?v=5.8"
                         parameters:parameters
                           progress:nil
                            success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                              

//                              NSLog(@"DETAIL JSON 2 : %@",responseObject);
                                
                                NSArray* dictionaryArray = [responseObject objectForKey:@"response"];
                                
                                AGUsersModel *user = [[AGUsersModel alloc]initWithServerResponse:[dictionaryArray firstObject]];
                                
                                if (success) {
                                    success(user);
                                }
                                
                                 [self hideActivityIndicator];
                            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                
                                NSLog(@"ERROR : %@",error );
                                
                                if (failure) {
                                    
                                    
                                    NSHTTPURLResponse* response = (NSHTTPURLResponse *)task.response;
                                    NSInteger statusCode = response.statusCode;
                                    
                                    NSLog(@"error: %@", [error localizedDescription]);
                                    
                                    failure(error, statusCode);
                                }
                                [self hideActivityIndicator];
                            }];

}

- (void) getCityNameID:(NSString *)cityID
              onSucces:(void (^)(NSString *))success
             onFailure:(void (^)(NSError *, NSInteger))failure {

    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                
                                cityID, @"city_ids",nil];
    [self showActivityIndicator];
    
    [self.requestSessionManager GET:@"database.getCitiesById?v=5.57"
                         parameters:parameters
                           progress:nil
                            success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                
//                                NSLog(@"ID info:%@",responseObject);
                                NSArray *arrayCity = [responseObject objectForKey:@"response"];
                                NSString *cityName = [[arrayCity firstObject]objectForKey:@"title"];
                                
//                                NSLog(@"%@",cityName);
                                if (cityName && success) {
                                    
                                    success (cityName);
                                }
                                [self hideActivityIndicator];
                            }
                            failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                
                                if (failure) {
                                    NSHTTPURLResponse* response = (NSHTTPURLResponse *)task.response;
                                    failure(error, response.statusCode);
                                }
                                
                                [self hideActivityIndicator];

                            }];


}

- (void) getSubscriptionsForUser:(NSString *)userID
                          offSet:(NSInteger) offset
                           count:(NSInteger) count
                       onSuccess:(void(^)(NSArray* subscriptionsGroups)) success
                       onFailure:(void(^)(NSError *error,NSInteger statusCode)) failure {
    
    [self showActivityIndicator];
    
    NSDictionary *paremeters = [NSDictionary dictionaryWithObjectsAndKeys:
                                userID,            @"user_id",
                                @"1",              @"extended",
                                @(count),          @"count",
                                @(offset),         @"offset",
                                @"name,photo_100", @"fields",nil];
    
    [self.requestSessionManager GET:@"users.getSubscriptions?v=5.57"
                         parameters:paremeters
                           progress:nil
                            success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                
                                NSLog(@"JSON Grops:%@",responseObject);
                                
                                NSArray *arrayDict =[[responseObject objectForKey:@"response"] objectForKey:@"items"];
                                 NSMutableArray *objectArray = [NSMutableArray array];
                                
                                for (NSDictionary *dictionary in arrayDict) {
                                    
                                    AGUsersModel *user = [[AGUsersModel alloc]initWithServerResponse:dictionary];
                                    [objectArray addObject:user];
                                }
                                
                                if (success) {
                                    success(objectArray);
                                }
                                NSLog(@"Parsing %@",objectArray);
                                [self hideActivityIndicator];

                                
                            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                
                                if (failure) {
                                    
                                    NSHTTPURLResponse* response = (NSHTTPURLResponse *)task.response;
                                    NSInteger statusCode = response.statusCode;
                                    
                                    NSLog(@"error: %@", [error localizedDescription]);
                                    
                                    failure(error, statusCode);
                                }

                            }];

}

- (void) getFollowersForUser:(NSString *)userID
                      offSet:(NSInteger)offset
                       count:(NSInteger)count
                   onSuccess:(void (^)(NSArray *))success
                   onFailure:(void (^)(NSError *, NSInteger))failure {

     [self showActivityIndicator];
    
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                userID, @"user_id",
                                @(count),@"count",
                                @(offset),@"offset",
                                @"photo_100",@"fields", nil];
    
[self.requestSessionManager GET:@"users.getFollowers?v=5.57"
                     parameters:parameters
                       progress:nil
                        success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                            
//                          NSLog(@"JSON followers:%@",responseObject);
                            
                            NSArray *dictArray = [[responseObject objectForKey:@"response"] objectForKey:@"items"];
                            
                            NSMutableArray *objectArray = [NSMutableArray array];
                            
                            for (NSDictionary *dictionary in dictArray) {
                                
                                AGUsersModel *userModel = [[AGUsersModel alloc]initWithServerResponse:dictionary];
                                [objectArray addObject:userModel];
                            }
                            
                            if (success) {
                                
                                success(objectArray);
                            }
                            
                             [self hideActivityIndicator];
                            
                        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                            
                            if (failure) {
                                
                                
                                NSHTTPURLResponse* response = (NSHTTPURLResponse *)task.response;
                                NSInteger statusCode = response.statusCode;
                                
                                NSLog(@"error: %@", [error localizedDescription]);
                                
                                failure(error, statusCode);
                            }

                        }];

  [self hideActivityIndicator];

}

- (void) getWallForUser:(NSString *)userID
                 offSet:(NSInteger)offSet
                  count:(NSInteger)count
              onSuccess:(void (^)(NSMutableArray *))success
              onFailure:(void (^)(NSError *, NSInteger statusCode))failure {

     //    http://vk.com/dev/wall.get
    
    [self showActivityIndicator];
    
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                userID,    @"owner_id",
                                @(offSet), @"offset",
                                @"owner",  @"filter",
                                @(count),  @"count",
                                @(0),      @"extended",
                                @"photo_50,name", @"fields", nil];
    
[self.requestSessionManager GET:@"wall.get?v=5.57"
                     parameters:parameters
                       progress:nil
                        success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                            
//                            NSLog(@"WALL: %@",responseObject);
                            
                            NSMutableArray *dictsArray = [[responseObject objectForKey:@"response"]objectForKey:@"items"];
                            NSMutableArray *objectsArray = [NSMutableArray array];
                            
                            for (NSDictionary *dict in dictsArray) {
                               
                                if (![dict isEqual:[dictsArray firstObject]]) {
                                    
                                    AGwallUsersModel* postInfo = [[AGwallUsersModel alloc] initWithServerResponseForWall:dict];
                                    
                                    [objectsArray addObject:postInfo];
                                    
                                }

                                
                            }
                            if (success) {
                                success(objectsArray);
                            }
                            
                            [self hideActivityIndicator];
                        }
                        failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                            
                            if (failure) {
                                
                                NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
                                NSInteger statusCode = response.statusCode;
                                
                                NSLog(@"error: %@",[error localizedDescription]);
                                
                                failure(error,statusCode);
                            }
                        }];
    
     [self hideActivityIndicator];

}

@end
