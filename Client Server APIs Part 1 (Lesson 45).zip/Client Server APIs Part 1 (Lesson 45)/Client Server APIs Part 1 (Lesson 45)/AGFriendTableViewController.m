//
//  AGFriendTableViewController.m
//  Client Server APIs Part 1 (Lesson 45)
//
//  Created by Anton Gorlov on 21.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGFriendTableViewController.h"
#import "AGServerManager.h"
#import "AGUserModel.h"
#import <UIImageView+AFNetworking.h>

@interface AGFriendTableViewController () <UITableViewDataSource>

@property (strong, nonatomic) NSMutableArray *friendsArray; // соз массив друзей будем сюда сохр

@end

@implementation AGFriendTableViewController

static NSInteger friendsInRequest = 20; //кол-во друзей по 20

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.friendsArray = [NSMutableArray array];
    [self getFriendsFromServer]; //вызываем метод
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//Откуда-то наших студентов нужно брать,соз метод

#pragma mark - API

- (void) getFriendsFromServer {
    
    [[AGServerManager sharedManager]
     
     getFriendsWithOffset:[self.friendsArray count] //при первом запуске будет 20 друзей,в след запуске с 20-го
     
     count:friendsInRequest
     
     onSuccess:^(NSArray *friends) { //если без ошибки, то пришли друзья
         
         NSMutableArray *newPaths = [NSMutableArray array];
         [self.friendsArray addObjectsFromArray:friends];//добавим всех друзей которые пришли в массив
         //обновляем таблицу
         for (int i = (int)[self.friendsArray count] - (int) [friends count]; i < [self.friendsArray count]; i++) { //friendsArray -текущий массив
             [newPaths addObject:[NSIndexPath indexPathForRow:i inSection:0]];// cop NSIndexPath для каждого добавленного друга
         }
         [self.tableView beginUpdates];
         
         [self.tableView insertRowsAtIndexPaths:newPaths withRowAnimation:UITableViewRowAnimationTop];
         
         [self.tableView endUpdates];
         
         
         //or
         
        // [self.tableView reloadData]; //обновляем таблицу
         
         
     }
     onFailure:^(NSError *error, NSInteger statusCode) {
         
         NSLog(@"Error: %@, code :%ld",[error localizedDescription],statusCode );
     }];
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {


    return [self.friendsArray count] +1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    if (indexPath.row == [self.friendsArray count]) { //если это последний ряд
        
        cell.textLabel.text = @"Load more friends"; // при нажатии на эту ячейку будет обновляться таблица и добавлять других друзей
        cell.imageView.image = nil;
        
    }else {
    
        AGUserModel *friend = [self.friendsArray objectAtIndex:indexPath.row]; //friend - it's NSDictionary
    
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", friend.firstName, friend.lastName];
    
        
        //КАК ЗАГРУЗТЬ ФОТО ??
        
        NSURLRequest *request = [NSURLRequest requestWithURL:friend.avatarURL]; // соз request imageView которая пришла
        
        __weak UITableViewCell *weakCell = cell; //соз слабую ссылку, так как исп-ем в блоке
        
        cell.imageView.image = nil;
        [cell.imageView setImageWithURLRequest:request
                              placeholderImage:nil
         // когда картинка скачалась,то вызываеться блок success
                                       success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
                                           
                                           weakCell.imageView.image = image;
                                           [weakCell layoutSubviews]; //перерисуем Subviews,так как изначально UITableViewCell у нее нету Image вначале
                                           
                                       } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
                                         
                                            NSLog(@"ERROOORR FAILURE IMAGE");
                                       }];
        
    }
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.row == [self.friendsArray count]) { //если нажимаем на последнюю ячейку
       
        [self getFriendsFromServer]; //добовляем друзей
    }
}


@end
