//
//  AGUserModel.m
//  Client Server APIs Part 1 (Lesson 45)
//
//  Created by Anton Gorlov on 22.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGUserModel.h"

@implementation AGUserModel

- (id) initWithServerResponse:(NSDictionary*) responseObject {

    self = [super init];
    
    if (self) {
        
        self.firstName = [responseObject objectForKey:@"first_name"];
        self.lastName = [responseObject objectForKey:@"last_name"];
        
        NSString *urlString = [responseObject objectForKey:@"photo_100"];
        
        if (urlString) {
            
            self.avatarURL = [NSURL URLWithString:urlString];
        }
    }
    return self;
}

@end
