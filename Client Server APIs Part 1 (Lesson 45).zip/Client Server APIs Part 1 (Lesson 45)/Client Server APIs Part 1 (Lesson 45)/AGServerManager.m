//
//  AGServerManager.m
//  Client Server APIs Part 1 (Lesson 45)
//
//  Created by Anton Gorlov on 21.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGServerManager.h"
#import <AFNetworking.h>
#import "AGUserModel.h"

@interface AGServerManager  ()

@property (strong, nonatomic) AFHTTPSessionManager *sessionManager;


@end

@implementation AGServerManager //мы будем стучатся с нашего APP на сервер,по этому соз этот клас,он отвечает за передачу данных

+ (AGServerManager*) sharedManager { //обьект создан будет один раз

    static AGServerManager *manager = nil;
  
    @synchronized (self) {
        
        if (manager == nil) {
            
            manager = [[self alloc]init]; //or manager = [[AGServerManager alloc]init];
        }
    }
       return manager;
}

- (id) init {

    self = [super init];
    
    if (self) {
        
        NSURL *url = [NSURL URLWithString:@"https://api.vk.com/method/"]; //род-кая URL,относит-но которого все будем строить (посылаем методы)
        
        
        self.sessionManager = [[AFHTTPSessionManager alloc] initWithBaseURL:url]; //инициализируем менеджер
        
    }
    return self;
}




//СОЗДАЕМ API ЗАПРОС

- (void) getFriendsWithOffset:(NSInteger)offset
                        count:(NSInteger)count
                    onSuccess:(void (^)(NSArray *))success
                    onFailure:(void (^)(NSError *, NSInteger))failure {
    
    //все запросы (GET, POST) принимают параметры.Параметры добавляем через Dictionary
    
    // params we get from http://vk.com/dev/friends.get
    
    NSDictionary *getParameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                   @"12198336",  @"user_id",
                                   @"name",      @"order",
                                   @(count),     @"count", //сокращение для NSNumber
                                   @(offset),    @"offset",
                                   @"photo_100", @"fields",
                                   @"nom",       @"name_case",
                                   @(5.53),      @"version", nil]; // обьект - ключ. НЕ ПУТАТЬ!!!
    
    [self.sessionManager
     GET:@"friends.get" //метод в контакте (это Синтаксис запроса - METHOD_NAME)
     parameters:getParameters
     progress:nil
     success:^(NSURLSessionTask * _Nonnull task, id  _Nullable responseObject) {
        
         NSLog(@"JSON: %@", responseObject);
         
         NSArray *dictsArray = [responseObject objectForKey:@"response"]; //массив friendsArray лежит в responseObject (это массив Dictionary)
         
         NSMutableArray *objectsArray = [NSMutableArray array]; //когда получили dictsArray,нужно превратить в dictsArray
         
         //КАК ПРЕВРАТИТЬ ????
         
         
         for (NSDictionary *dict in dictsArray) { //для каждой NSDictionary из массива dictsArray, добавим userModel (создадим)
             
             AGUserModel *userModel = [[AGUserModel alloc] initWithServerResponse:dict];
             [objectsArray addObject:userModel]; //добавляем
         }
         if (success) { //если передали наш блок "success" ,то вернем objectsArray (массив студентов)
             
             success(objectsArray);
         }
     }
     
     failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
         NSLog(@"Error: %@",error);
 
         if (failure) {
             failure(error, task.response.expectedContentLength);
         }
     }];
    
}


@end
