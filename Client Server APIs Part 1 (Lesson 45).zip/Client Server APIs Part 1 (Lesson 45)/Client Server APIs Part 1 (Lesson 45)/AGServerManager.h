//
//  AGServerManager.h
//  Client Server APIs Part 1 (Lesson 45)
//
//  Created by Anton Gorlov on 21.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGServerManager : NSObject

+ (AGServerManager*) sharedManager;//create singleton

//соз метод,который будет вызывать друзей.Параметры,которые будет пересылать (count, offset - это методы API)

- (void) getFriendsWithOffset:(NSInteger) offset //void ничего не возвращает
                        count:(NSInteger) count
                    onSuccess:(void (^)(NSArray *friends)) success  //массив друзей (блок)
                    onFailure:(void (^)(NSError *error,NSInteger statusCode)) failure; //statusCode если ошибка была


//все методы асинхронны,мы не можем ждать ответа,делаем в фоновом потоке.Поэтому нам нужно знать когда request закончиться, и потом берем friends ,когда заканчиться ба если ошибка,то берем ошибку.Поэтому добавим 2 блока "onSuccess" and "onFailure"
@end
