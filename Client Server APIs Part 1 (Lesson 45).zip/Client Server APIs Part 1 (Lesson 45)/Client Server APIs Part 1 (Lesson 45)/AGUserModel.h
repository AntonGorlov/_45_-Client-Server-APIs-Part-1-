//
//  AGUserModel.h
//  Client Server APIs Part 1 (Lesson 45)
//
//  Created by Anton Gorlov on 22.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGUserModel : NSObject //Создадим модель (этот класс) для нашего FRIEND (Лучше работать с моделью,чем на прямую с Dictionary)

//Добавим те поля, которые используем

@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSURL    *avatarURL;


- (id) initWithServerResponse:(NSDictionary*) responseObject; //соз метод

@end
