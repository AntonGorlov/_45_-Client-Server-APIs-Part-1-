//
//  AGFriendTableViewController.h
//  Client Server APIs Part 1 (Lesson 45)
//
//  Created by Anton Gorlov on 21.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGFriendTableViewController : UITableViewController

@end
